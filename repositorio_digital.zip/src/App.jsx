import React from 'react';

export default function App() {
  return (
    <div className="p-4 text-center text-xl font-bold text-blue-600">
      Repositorio Digital - Revista Cultural
    </div>
  );
}
