# Repositorio Digital - Revista Cultural

Este proyecto contiene la base para un repositorio digital con:
- React + Tailwind
- Netlify CMS para gestión de artículos

## Scripts disponibles

- `npm run dev` → modo desarrollo
- `npm run build` → construir proyecto
- `npm run preview` → previsualizar
